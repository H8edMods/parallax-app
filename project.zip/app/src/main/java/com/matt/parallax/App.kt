package com.matt.parallax

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

class Layer(var file: String) {
    var depth = 0f; var scale = 1f; var x = 0f; var y = 0f; var rot = 0f
    var op = 1f; var motion = 0; var vis = true
    @Volatile var bmp: Bitmap? = null
}

class Project(var strength: Float = 1f, var layers: MutableList<Layer> = mutableListOf())

object Store {
    fun dir(c: Context): File = File(c.filesDir, "layers").also { it.mkdirs() }
    fun pf(c: Context): File = File(c.filesDir, "project.json")

    fun load(c: Context): Project {
        val p = Project()
        try {
            val o = JSONObject(pf(c).readText())
            p.strength = o.optDouble("strength", 1.0).toFloat()
            val a = o.getJSONArray("layers")
            for (i in 0 until a.length()) {
                val j = a.getJSONObject(i)
                val l = Layer(j.getString("file"))
                if (!File(dir(c), l.file).exists()) continue
                l.depth = j.optDouble("depth", 0.0).toFloat()
                l.scale = j.optDouble("scale", 1.0).toFloat()
                l.x = j.optDouble("x", 0.0).toFloat()
                l.y = j.optDouble("y", 0.0).toFloat()
                l.rot = j.optDouble("rot", 0.0).toFloat()
                l.op = j.optDouble("op", 1.0).toFloat()
                l.motion = j.optInt("motion", 0)
                l.vis = j.optBoolean("vis", true)
                p.layers.add(l)
            }
        } catch (e: Exception) {
        }
        return p
    }

    fun save(c: Context, p: Project) {
        val a = JSONArray()
        for (l in p.layers) {
            a.put(
                JSONObject().put("file", l.file).put("depth", l.depth.toDouble())
                    .put("scale", l.scale.toDouble()).put("x", l.x.toDouble()).put("y", l.y.toDouble())
                    .put("rot", l.rot.toDouble()).put("op", l.op.toDouble()).put("motion", l.motion)
                    .put("vis", l.vis)
            )
        }
        pf(c).writeText(JSONObject().put("strength", p.strength.toDouble()).put("layers", a).toString())
    }

    fun decode(c: Context, l: Layer): Bitmap? = BitmapFactory.decodeFile(File(dir(c), l.file).path)

    // Copies any image Android can decode (PNG, JPEG, WebP, GIF, BMP, HEIC, AVIF on newer Android) into app storage.
    fun importUri(c: Context, u: Uri): String? {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var ss = 1
            while (max(bounds.outWidth, bounds.outHeight) / ss > 2048) ss *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = ss }
            val bmp = c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
            var bm: Bitmap = bmp
            try {
                val ori = c.contentResolver.openInputStream(u)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
                } ?: 1
                val deg = when (ori) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
                if (deg != 0f) {
                    bm = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
                }
            } catch (e: Exception) {
            }
            val name = "l" + System.currentTimeMillis() + "_" + (Math.random() * 1000).toInt()
            File(dir(c), name).outputStream().use {
                if (bm.hasAlpha()) bm.compress(Bitmap.CompressFormat.PNG, 100, it)
                else bm.compress(Bitmap.CompressFormat.JPEG, 94, it)
            }
            return name
        } catch (e: Exception) {
            return null
        }
    }
}

object Renderer {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    fun now(): Float = ((System.nanoTime() / 1_000_000L) % 3_600_000L) / 1000f

    fun draw(cv: Canvas, W: Float, H: Float, layers: List<Layer>, tx: Float, ty: Float, strength: Float, t: Float) {
        cv.drawColor(Color.BLACK)
        for ((i, l) in layers.withIndex()) {
            val b = l.bmp ?: continue
            if (!l.vis) continue
            val k = strength * (1f + 19f * (strength / 2.5f) * (strength / 2.5f))
            val d = l.depth / 100f * k
            var ox = -tx * d * W * .09f + l.x * W / 100f
            var oy = -ty * d * H * .09f + l.y * H / 100f
            var s = max(W / b.width, H / b.height) * l.scale * (1f + min(.2f * abs(d), .6f))
            var r = l.rot
            when (l.motion) {
                1 -> { ox += cos(t * .9f + i) * W * .015f; oy += sin(t * 1.2f + i) * H * .012f }
                2 -> s *= 1f + sin(t * 1.8f + i) * .035f
                3 -> r += t * 14f
                4 -> ox += ((t * W * .033f + i * W * .08f) % (W * .3f)) - W * .15f
            }
            paint.alpha = (l.op.coerceIn(0f, 1f) * 255).toInt()
            cv.save()
            cv.translate(W / 2 + ox, H / 2 + oy)
            cv.rotate(r)
            cv.scale(s, s)
            cv.drawBitmap(b, -b.width / 2f, -b.height / 2f, paint)
            cv.restore()
        }
    }
}

// Gyro-based tilt. Baseline slowly follows your hold angle so the scene recentres itself.
class Tilt(c: Context) : SensorEventListener {
    private val sm = c.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sensor: Sensor? = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
        ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val m = FloatArray(9)
    private var bx = 0f
    private var by = 0f
    private var init = false
    @Volatile var tx = 0f
    @Volatile var ty = 0f
    var range = 25f

    fun start() {
        init = false
        sensor?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    fun stop() { sm.unregisterListener(this) }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onSensorChanged(e: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(m, e.values)
        val gx = Math.toDegrees(asin((-m[6]).coerceIn(-1f, 1f).toDouble())).toFloat()
        val gy = Math.toDegrees(atan2(m[7], m[8]).toDouble()).toFloat()
        if (!init) { bx = gx; by = gy; init = true }
        bx += (gx - bx) * .004f
        by += (gy - by) * .004f
        tx = ((gx - bx) / range).coerceIn(-1f, 1f)
        ty = ((gy - by) / range).coerceIn(-1f, 1f)
    }
}

class EditorView(c: Context) : View(c) {
    var proj = Project()
    var sel = -1
    val tilt = Tilt(c)
    var onChange: (() -> Unit)? = null
    private var sx = 0f
    private var sy = 0f
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lx = 0f; private var ly = 0f; private var ld = 0f; private var la = 0f; private var ln = -1

    override fun onDraw(cv: Canvas) {
        sx += (tilt.tx - sx) * .15f
        sy += (tilt.ty - sy) * .15f
        Renderer.draw(cv, width.toFloat(), height.toFloat(), proj.layers, sx, sy, proj.strength, Renderer.now())
        if (proj.layers.isEmpty()) {
            tp.color = Color.WHITE; tp.textSize = 44f; tp.textAlign = Paint.Align.CENTER
            cv.drawText("Tap Add images below", width / 2f, height / 2f, tp)
        }
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val l = proj.layers.getOrNull(sel) ?: return true
        val n = e.pointerCount
        var cx = 0f
        var cy = 0f
        for (i in 0 until n) { cx += e.getX(i); cy += e.getY(i) }
        cx /= n; cy /= n
        var d = 0f
        var a = 0f
        if (n >= 2) {
            val dx = e.getX(1) - e.getX(0)
            val dy = e.getY(1) - e.getY(0)
            d = hypot(dx, dy)
            a = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                if (n == ln) {
                    l.x += (cx - lx) / width * 100f
                    l.y += (cy - ly) / height * 100f
                    if (n >= 2 && ld > 0f) {
                        l.scale = (l.scale * d / ld).coerceIn(.1f, 5f)
                        var da = a - la
                        if (da > 180f) da -= 360f
                        if (da < -180f) da += 360f
                        l.rot = (l.rot + da + 540f) % 360f - 180f
                    }
                }
                ln = n; lx = cx; ly = cy; ld = d; la = a
            }
            MotionEvent.ACTION_UP -> { ln = -1; onChange?.invoke() }
            else -> ln = -1
        }
        return true
    }
}

class MainActivity : Activity() {
    private lateinit var proj: Project
    private lateinit var ev: EditorView
    private lateinit var panel: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        proj = Store.load(this)
        ev = EditorView(this)
        ev.proj = proj
        ev.onChange = { save(); build() }
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.rgb(12, 12, 18))
        root.fitsSystemWindows = true
        root.addView(ev, LinearLayout.LayoutParams(-1, 0, 1f))
        val sv = ScrollView(this)
        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(12), dp(8), dp(12), dp(24))
        sv.addView(panel)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1.2f))
        setContentView(root)
        build()
        Thread {
            for (l in proj.layers) l.bmp = Store.decode(this, l)
            runOnUiThread { ev.sel = proj.layers.size - 1; build() }
        }.start()
    }

    override fun onResume() { super.onResume(); ev.tilt.start() }
    override fun onPause() { super.onPause(); ev.tilt.stop(); save() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun save() = Store.save(this, proj)

    private fun btn(t: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { f() }
        return b
    }

    private fun label(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.LTGRAY)
        return tv
    }

    private fun seek(name: String, lo: Int, hi: Int, v: Float, f: (Float) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val tv = label("$name: ${v.roundToInt()}")
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = (v - lo).roundToInt().coerceIn(0, hi - lo)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) { val x = (p + lo).toFloat(); tv.text = "$name: ${x.roundToInt()}"; f(x) }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { save() }
        })
        box.addView(tv)
        box.addView(sb)
        return box
    }

    private fun build() {
        panel.removeAllViews()
        val row = LinearLayout(this)
        row.addView(btn("Add images") { pick() }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("Set as wallpaper") { setWp() }, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(row)
        panel.addView(label("Drag = move, pinch = zoom, twist = rotate (selected layer, 1 = back)"))
        val hs = HorizontalScrollView(this)
        val chips = LinearLayout(this)
        for ((i, l) in proj.layers.withIndex()) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(l.bmp)
            iv.setBackgroundColor(if (i == ev.sel) Color.rgb(138, 107, 255) else Color.DKGRAY)
            iv.setPadding(dp(3), dp(3), dp(3), dp(3))
            iv.alpha = if (l.vis) 1f else .4f
            iv.setOnClickListener { ev.sel = i; build() }
            val lp = LinearLayout.LayoutParams(dp(64), dp(64))
            lp.setMargins(0, dp(8), dp(8), dp(8))
            chips.addView(iv, lp)
        }
        hs.addView(chips)
        panel.addView(hs)
        val l = proj.layers.getOrNull(ev.sel)
        if (l != null) {
            panel.addView(seek("Depth", -100, 100, l.depth) { l.depth = it })
            panel.addView(seek("Opacity", 0, 100, l.op * 100f) { l.op = it / 100f })
            panel.addView(seek("Zoom %", 10, 500, l.scale * 100f) { l.scale = it / 100f })
            panel.addView(seek("Rotate", -180, 180, l.rot) { l.rot = it })
            val sp = Spinner(this)
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("none", "float", "pulse", "spin", "drift"))
            sp.setSelection(l.motion)
            sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (l.motion != pos) { l.motion = pos; save() }
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
            panel.addView(label("4D motion"))
            panel.addView(sp)
            val r2 = LinearLayout(this)
            r2.addView(btn("◀ Back") { move(-1) }, LinearLayout.LayoutParams(0, -2, 1f))
            r2.addView(btn("Front ▶") { move(1) }, LinearLayout.LayoutParams(0, -2, 1f))
            r2.addView(btn(if (l.vis) "Hide" else "Show") { l.vis = !l.vis; save(); build() }, LinearLayout.LayoutParams(0, -2, 1f))
            r2.addView(btn("Delete") { del() }, LinearLayout.LayoutParams(0, -2, 1f))
            panel.addView(r2)
        }
        panel.addView(seek("Parallax strength (all layers)", 0, 250, proj.strength * 100f) { proj.strength = it / 100f })
    }

    private fun move(d: Int) {
        val j = ev.sel + d
        if (j < 0 || j >= proj.layers.size) return
        java.util.Collections.swap(proj.layers, ev.sel, j)
        ev.sel = j; save(); build()
    }

    private fun del() {
        val l = proj.layers.getOrNull(ev.sel) ?: return
        File(Store.dir(this), l.file).delete()
        proj.layers.removeAt(ev.sel)
        ev.sel = min(ev.sel, proj.layers.size - 1)
        save(); build()
    }

    private fun pick() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(Intent.createChooser(i, "Add images"), 7)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 7 || resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { for (k in 0 until it.itemCount) uris.add(it.getItemAt(k).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        Toast.makeText(this, "Importing...", Toast.LENGTH_SHORT).show()
        Thread {
            val made = mutableListOf<Layer>()
            for (u in uris) {
                val n = Store.importUri(this, u) ?: continue
                val l = Layer(n)
                l.bmp = Store.decode(this, l)
                l.depth = min((proj.layers.size + made.size) * 20f, 100f)
                made.add(l)
            }
            runOnUiThread {
                proj.layers.addAll(made)
                ev.sel = proj.layers.size - 1
                save(); build()
                if (made.size < uris.size) Toast.makeText(this, "Some files could not be read", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun setWp() {
        save()
        try {
            startActivity(
                Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this, ParallaxWallpaperService::class.java)
                )
            )
        } catch (e: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }
}

class ParallaxWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = ParallaxEngine()

    inner class ParallaxEngine : Engine() {
        private val ctx = this@ParallaxWallpaperService
        private val tilt = Tilt(ctx)
        private val handler = Handler(Looper.getMainLooper())
        @Volatile private var layers: List<Layer> = emptyList()
        @Volatile private var strength = 1f
        @Volatile private var stamp = -1L
        private var visible = false
        private var sx = 0f
        private var sy = 0f

        private val frame = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) handler.postDelayed(this, 16)
            }
        }

        private fun reload() {
            val st = Store.pf(ctx).lastModified()
            if (st == stamp) return
            Thread {
                val p = Store.load(ctx)
                for (l in p.layers) l.bmp = Store.decode(ctx, l)
                strength = p.strength
                layers = p.layers
                stamp = st
            }.start()
        }

        private fun drawFrame() {
            val h = surfaceHolder
            var c: Canvas? = null
            try {
                c = h.lockHardwareCanvas()
                if (c != null) {
                    sx += (tilt.tx - sx) * .15f
                    sy += (tilt.ty - sy) * .15f
                    Renderer.draw(c, c.width.toFloat(), c.height.toFloat(), layers, sx, sy, strength, Renderer.now())
                }
            } catch (e: Exception) {
            } finally {
                if (c != null) try { h.unlockCanvasAndPost(c) } catch (e: Exception) {}
            }
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            handler.removeCallbacks(frame)
            if (v) { reload(); tilt.start(); handler.post(frame) } else tilt.stop()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder?) {
            visible = false
            handler.removeCallbacks(frame)
            tilt.stop()
            super.onSurfaceDestroyed(holder)
        }
    }
}
